from exercicio2 import calcular_frete

def test_frete_1kg():
    assert calcular_frete(1.0) == 5

def test_frete_101kg():
    assert calcular_frete(1.01) == 10

def test_frete_5kg():
    assert calcular_frete(5.0) == 10

def test_frete_501kg():
    assert calcular_frete(5.01) == 18

def test_frete_zero():
    assert calcular_frete(0) == 0

def test_frete_negativo():
    assert calcular_frete(-10) == 0